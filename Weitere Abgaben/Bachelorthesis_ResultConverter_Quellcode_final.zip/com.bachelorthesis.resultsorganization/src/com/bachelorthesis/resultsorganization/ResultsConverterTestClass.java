package com.bachelorthesis.resultsorganization;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.JTextArea;

import org.junit.Test;

public class ResultsConverterTestClass {
	
	NodePair np1;
	NodePair np2;
	JTextArea ta1;
	JTextArea ta2;
	
	
	
	@Test
	public void testNodePair() {
		np1 = new NodePair("A", "B");
		np2 = new NodePair("A", "B");
		assertEquals(np1.getNodeOne(),np2.getNodeOne());
		assertEquals(np1.getNodeTwo(),np2.getNodeTwo());
		assertFalse(np1.getNodeOne().equals(np2.getNodeTwo()));
		assertFalse(np1.getNodeTwo().equals(np2.getNodeOne()));
		
		assertEquals(np1.getNodeStrings(), np2.getNodeStrings());
		assertEquals(np1.getStringRepresentation(), np2.getStringRepresentation());
		assertEquals(np1.getStringRepresentation(), "A; B; 1;");
		assertFalse(np1.getStringRepresentation().equals("B; A; 1;"));
		
		np1.incrementCount();
		assertFalse(np1.getStringRepresentation().equals(np2.getStringRepresentation()));
		assertEquals(np1.getStringRepresentation(), "A; B; 2;");
		assertFalse(np1.getStringRepresentation().equals("A; B; 1;"));
		
		np2.incrementCount();
		assertEquals(np1.getStringRepresentation(), np2.getStringRepresentation());
		
		np2 = new NodePair("A", "C");
		assertEquals(np1.getNodeOne(),np2.getNodeOne());
		assertFalse(np1.getNodeTwo().equals(np2.getNodeTwo()));
	}
	
	@Test
	public void testMainFunction() throws IOException {
		MainClass.main(null);
		ta1 = new JTextArea();
		ta2 = new JTextArea();
		MainClass.readFile("TestFile.txt", ta1);
		MainClass.saveFile("ResultFile.txt", ta1);
		ta1.append("\n");
		
		BufferedReader reader = new BufferedReader(new FileReader("ResultComparisonFile.txt"));
		String line;
		line = reader.readLine();
		while (line != null) {
			ta2.append(line + "\n");
			line = reader.readLine();
		}
		reader.close();
		assertEquals(ta1.getText(), ta2.getText());
	}
	
}

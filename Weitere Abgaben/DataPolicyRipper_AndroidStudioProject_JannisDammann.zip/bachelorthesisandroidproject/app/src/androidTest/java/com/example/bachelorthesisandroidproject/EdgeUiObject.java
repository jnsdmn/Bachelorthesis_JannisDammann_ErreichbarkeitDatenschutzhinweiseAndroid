package com.example.bachelorthesisandroidproject;

import android.util.Log;

import androidx.test.uiautomator.UiObject;
import androidx.test.uiautomator.UiObjectNotFoundException;

import static android.content.ContentValues.TAG;

/**
 * Diese Klasse erweitert die abstrakte Repräsentation einer Interaktion für ein UiObject.
 *
 * @version 1.0 11.08.2020
 * @author Jannis Dammann
 */
public class EdgeUiObject extends AbstractEdgeInteraction {

    private UiObject object; // das UiObject

    /**
     * Konstruktor der Klasse. Instanziiert alle Felder von der Super-Klasse sowie die von dieser Klasse.
     * @param o das UiObject
     * @param pref die Präferenz der Interaktion
     */
    public EdgeUiObject(UiObject o, int pref) {
        super(pref, "", "");
        object = o;
        try {
            super.setClassname(buildClassname());
            super.setEdgeText(getTextInfo());
        } catch (UiObjectNotFoundException e) {
            Log.e(TAG, "Fehler in Instanziierung eines EdgeUiObject", e);
        }
    }

    /**
     * Diese Methode führt eine Interaktion an dem UiObject aus.
     */
    public void interact() {
        try {
            object.clickAndWaitForNewWindow();
        } catch (UiObjectNotFoundException e) {
            Log.e(TAG, "Fehler in EdgeUiObject interact()", e);
        }
    }

    /**
     * Getter für das UiObject
     * @return das UiObject
     */
    public UiObject getObject() {
        return object;
    }

    /**
     * Diese Methode ermittelt den Typen der Interaktion.
     * @return den Typen der Interaktion als String
     */
    private String buildClassname() throws UiObjectNotFoundException {
        String classname = "";
            for (String s: object.getClassName().split("\\.")) {
                classname = s;
            }
        return classname;
    }

    /**
     * Diese Methode ermittelt, ob das UiObject eine Textbeschreibung oder einen Text beinhaltet und speichert diesen in der
     * Klassenvariablen.
     * @throws UiObjectNotFoundException
     */
    private String getTextInfo() throws UiObjectNotFoundException {
        String edgeText;
        if (object.getText() != "") {
            edgeText = object.getText();
        }
        else if (object.getContentDescription() != "") {
            edgeText = object.getContentDescription();
        }
        else {
            edgeText = "";
        }
        return edgeText;
    }
}
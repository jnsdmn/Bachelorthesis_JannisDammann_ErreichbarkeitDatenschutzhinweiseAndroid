package com.bachelorthesis.resultsorganization;
/**
 * Diese Klasse repr�sentiert ein Knotenpaar
 * @author Jannis Dammann
 *
 */
public class NodePair {
	private String node1;
	private String node2;
	private int countOfNode;
	
	public NodePair(String n1, String n2) {
		node1 = n1;
		node2 = n2;
		countOfNode = 1;
	}
	
	public void incrementCount() {
		countOfNode++;
	}
	
	public String getStringRepresentation() {
		String result = "";
		result = result.concat(node1 + "; ");
		result = result.concat(node2 + "; ");
		result = result.concat(Integer.toString(countOfNode) + ";");
		return result;
	}
	
	public String getNodeStrings() {
		return node1 + ";" + node2 + ";";
	}
	
	public String getNodeOne() {
		return node1;
	}
	
	public String getNodeTwo() {
		return node2;
	}
}

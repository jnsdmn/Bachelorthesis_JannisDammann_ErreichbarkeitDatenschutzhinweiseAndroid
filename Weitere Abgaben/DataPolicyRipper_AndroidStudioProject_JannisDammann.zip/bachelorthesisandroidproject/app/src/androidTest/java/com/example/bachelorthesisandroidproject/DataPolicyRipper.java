package com.example.bachelorthesisandroidproject;

import android.util.Log;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.filters.SdkSuppress;
import androidx.test.uiautomator.By;
import androidx.test.uiautomator.UiDevice;
import androidx.test.uiautomator.UiObject;
import androidx.test.uiautomator.UiObjectNotFoundException;
import androidx.test.uiautomator.UiSelector;
import androidx.test.uiautomator.Until;

import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.ArrayList;
import java.util.List;

import static android.content.ContentValues.TAG;
import static androidx.test.platform.app.InstrumentationRegistry.getInstrumentation;
import static org.hamcrest.core.IsNull.notNullValue;
import static org.junit.Assert.assertThat;

@RunWith(AndroidJUnit4.class)
@SdkSuppress(minSdkVersion = 18)
/**
 * Diese Klasse ist dafür zuständig, die Suche für die jeweiligen Anwendungen zu instanziieren und die
 * Ergebnisse in den Log von AndroidStudio zu schreiben.
 *
 * @version 1.0 11.08.2020
 * @author Jannis Dammann
 */
public class DataPolicyRipper {

    private static final int LAUNCH_TIMEOUT = 5000;
    private static final String TAG = "Results";
    private UiDevice device;    // Das Gerät, das genutzt wird
    private BFSSearch bfs;      //Die Instanz der Breitensuche, die genutzt wird

    @Test
    /**
     * Diese Testmethode instanziiert und startet die Suche nach Datenschutzhinweisen in allen Apps, die
     * in einem Ordner auf dem Startbildschirm des Emulators mit der Beschriftung "Tested Apps" hinterlegt sind.
     */
    public void startSearchFromFolder() {
        // Initialize UiDevice instance
        device = UiDevice.getInstance(getInstrumentation());

        // Best Practice to start from Home Screen
        device.pressHome();

        // Wait for device launcher
        final String launcherPackage = device.getLauncherPackageName();
        assertThat(launcherPackage, notNullValue());
        device.wait(Until.hasObject(By.pkg(launcherPackage).depth(0)), LAUNCH_TIMEOUT);

        // Launch the app folder
        UiObject appFolder = device.findObject(new UiSelector().descriptionContains("Folder: Tested Apps"));
        try {
            appFolder.clickAndWaitForNewWindow();
        } catch (UiObjectNotFoundException e) {
            Log.e(TAG, "Fehler in DataPolicyRipper", e);
        }

        // Launch the different apps
        List<UiObject> testedApps = new ArrayList<UiObject>();
        int i = 0;
        UiObject obj = null;
        do {
            obj = null;
            obj = device.findObject(new UiSelector().clickable(true).instance(i++));
            if(obj != null && obj.exists()) {
                testedApps.add(obj);
            }
        } while(obj != null && obj.exists());

        // Remove last element (Edit Text for App Folder)
        testedApps.remove(testedApps.size()-1);
        testedApps.remove(testedApps.size()-1);

        // Create list for solutions
        ArrayList<String> solutionsList = new ArrayList<String>();

        // Search for data policy in every app in folder
        for (UiObject app: testedApps) {
            try {
                app.clickAndWaitForNewWindow();
                NodeScreen startNode = new NodeScreen(null, null);
                bfs = new BFSSearch(startNode, app, true);
                solutionsList.add(bfs.search());
                // Search uninformed if informed search did not find solution
                if (solutionsList.get(solutionsList.size()-1).contains("Es wurden keine Datenschutzhinweise gefunden.")) {
                    solutionsList.remove(solutionsList.size()-1);
                    startNode = new NodeScreen(null, null);
                    bfs = new BFSSearch(startNode, app, false);
                    solutionsList.add(bfs.search());
                }
            } catch (UiObjectNotFoundException e) {
                Log.e(TAG, "Fehler in DataPolicyRipper", e);
            }
            device.pressHome();
            try {
                appFolder.clickAndWaitForNewWindow();
            } catch (UiObjectNotFoundException e) {
                Log.e(TAG, "Fehler in DatPolicyRipper", e);
            }
        }
        writeResultsToConsole(solutionsList);
    }

    /**
     * Diese Methode schreibt die Strings aus einer Liste in den LogCat von Android Studio und in die Konsole.
     * Die Ergebnisse können im LogCat über den Tag "Results" gefunden werden.
     * @param pathList Eine Liste mit Pfaden zu Datenschutzhinweisen für jede getestete Anwendung
     */
    private void writeResultsToConsole(ArrayList<String> pathList) {
        for (String s: pathList) {
            System.out.println(s);
            Log.e(TAG, s);
        }
    }
}
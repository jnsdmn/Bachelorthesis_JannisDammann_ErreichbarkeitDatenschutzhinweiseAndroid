package com.example.bachelorthesisandroidproject;

import androidx.test.uiautomator.UiObject;

/**
 * Diese Klasse implementiert die abstrakte Repräsentation einer Kante in dem zu durchsuchenden Graphen.
 *
 * @version 1.0 11.08.2020
 * @author Jannis Dammann
 */
public abstract class AbstractEdgeInteraction {

    private int preference;                 // The Preference of the interaction
    private String classname;               // The classname of the interaction
    private String edgeText;                // The text or description of the interaction

    /**
     * Konstruktor für die abstrakte Klasse. Setzt die Felder der Klasse.
     * @param pref Präferenz der Interaktion
     * @param cn Typ der Interaktion
     * @param et Beschreibungstext der Interaktion
     */
    public AbstractEdgeInteraction(int pref, String cn, String et) {
        preference = pref;
        classname = cn;
        edgeText = et;
    }

    /**
     * Getter für die Präferenz
     * @return die Präferenz der Interaktion
     */
    public int getPreference() {
        return preference;
    }

    /**
     * Getter für den Typnamen der Interaktion
     * @return den Classname der Interaktion
     */
    public String getClassname() {
        return classname;
    }

    /**
     * Getter für den Text/Beschreibungstext der Interaktion
     * @return den Text der Interaktion
     */
    public String getEdgeText() {
        return edgeText;
    }

    /**
     * Setter für den Classname
     * @param cn der zu setzende Klassenname
     */
    public void setClassname(String cn) {
        classname = cn;
    }

    /**
     * Setter für den Text der Interaktion
     * @param et der zu setzende Text
     */
    public void setEdgeText(String et) {
        edgeText = et;
    }

    /**
     * Abstrakte Methode, die eine Interaktion ausführen soll.
     */
    public abstract void interact();

    /**
     * Abstrakte Methode, die das UiObject ausgibt.
     * @return UiObject
     */
    public abstract UiObject getObject();

}
package com.example.bachelorthesisandroidproject;

import android.os.RemoteException;
import android.util.Log;

import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.uiautomator.By;
import androidx.test.uiautomator.UiDevice;
import androidx.test.uiautomator.UiObject;
import androidx.test.uiautomator.UiObjectNotFoundException;
import androidx.test.uiautomator.UiScrollable;
import androidx.test.uiautomator.UiSelector;
import androidx.test.uiautomator.Until;


import java.util.ArrayList;
import java.util.LinkedList;

import static android.content.ContentValues.TAG;

/**
 * Diese Klasse implementiert eine Breitensuche nach Datenschutzhinweisen in einer Anwendung.
 *
 * @version 1.0 11.08.2020
 * @author Jannis Dammann
 */
public class BFSSearch {

    private static int maxDepth = 9;                        // The maximum depth that will be searched

    private NodeScreen startNode;                           // The node from which the search is being started
    private LinkedList<ArrayList<NodeScreen>> frontier;     // The list in which the paths that will be searched are held
    private ArrayList<NodeScreen> currentPath;              // The current path that is being searched
    private ArrayList<NodeScreen> currentPathCopy;          // A copy of the current path for purposes of expanding it
    private AbstractEdgeInteraction currentInteraction;     // The current interaction that leads to the node that is being searched
    private UiDevice device;
    private UiObject appIcon;
    private boolean finished;                               // Boolean that states if the search is finished or not
    private String appPkg;
    private ArrayList<NodeScreen> visitedNodes;             // A list of all the nodes that have been searched
    private boolean informedSearch;                         // Boolean that states if the search is informed or not
    private int currentDepthIndex;                          // Integer, that tracks where the first path with the current depth is located on the frontier
    private int previousDepthIndex;
    private long startTime;
    private long endTime;

    /**
     * Konstruktor für die Klasse, der alle Variablen instanziiert und den Startknoten vorbereitet.
     * @param screen Der Startknoten der Suche
     * @param app Der Button, der die App startet, die durchsucht wird
     * @param searchType true, wenn informed search, false, wenn nicht
     */
    public BFSSearch(NodeScreen screen, UiObject app, boolean searchType) {
        // Set up device
        device = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        startNode = screen;
        // Set type of search
        informedSearch = searchType;
        // Set up start node
        if (informedSearch) {
            startNode.setUpInformedSearch();
        }
        else {
            startNode.setUp();
        }
        // Add start path containing only start node to frontier
        ArrayList<NodeScreen> startPath = new ArrayList<NodeScreen>();
        startPath.add(startNode);
        frontier = new LinkedList<ArrayList<NodeScreen>>();
        frontier.add(startPath);
        // Add start node to list of already visited nodes
        visitedNodes = new ArrayList<NodeScreen>();
        visitedNodes.add(startNode);

        // Set the rest of the variables
        finished = false;
        appIcon = app;
        currentDepthIndex = 0;
        previousDepthIndex = 0;
        appPkg = device.getCurrentPackageName();

        // Set the start and end time of the search
        startTime = System.currentTimeMillis();
        endTime = startTime + 30*60*1000;
    }

    /**
     * Diese Methode führt eine Tiefensuche nach Datenschutzhinweisen aus.
     * @return Einen String, der den kürzesten Pfad zu den Datenschutzhinweisen repräsentiert
     */
    public String search() {
        // Initialize the currentInteraction as null
        currentInteraction = null;
        do {
            // Get current path to search from frontier (BFS -> FIFO)
            currentPath = null;
            currentPath = new ArrayList<NodeScreen>(frontier.get(0));
            // Remove currentPath from frontier and adjust indexes for sorting into frontier
            frontier.remove(0);
            if (currentDepthIndex > 0) {
                currentDepthIndex--;
            }
            if (previousDepthIndex > 0) {
                previousDepthIndex--;
            }
            // Get the NodeScreen we want to search (Last screen on path)
            NodeScreen lastItem = currentPath.get(currentPath.size()-1);
            // Navigate to the screen that we want to search
            runInteractionPath(getInteractionPath(currentPath));
            // Check if the searched screen is our goal
            if (lastItem.isGoal()) {
                return finishSearch();
            }
            else if (!finished) {
                // Iterate through every child of the current screen
                for (NodeScreen child: lastItem.getChildrenList()) {
                    // Create copy of current path to work with
                    currentPathCopy = new ArrayList<NodeScreen>(currentPath);
                    // Get the interaction that leads from the last screen to this one
                    currentInteraction = lastItem.getInteractionList().get(lastItem.getChildrenList().indexOf(child));
                    // use that interaction
                    currentInteraction.interact();
                    // Set up the screen so we can work with it later
                    if (informedSearch) {
                        if (child.setUpInformedSearch()) {
                            // if the node leads to a goal node stop the search
                            return finishSearchForLoop(child);
                        }
                    }
                    else {
                        if(child.setUp()) {
                            // if the node leads to a goal node stop the search
                            return finishSearchForLoop(child);
                        }
                    }
                    // Expand the current path with the searched node
                    currentPathCopy.add(child);
                    // Set the depth indexes for sorting into the frontier if needed
                    if (frontier.size() == 0 || currentPathCopy.size() > frontier.get(currentDepthIndex).size()) {
                        previousDepthIndex = currentDepthIndex;
                        currentDepthIndex = frontier.size();
                    }
                    // Sort a path with a preferred node into the frontier if the search is not informed
                    if (!informedSearch && child.isPreferredNode()) {
                        sortIntoFrontier(currentPathCopy);
                    }
                    else {
                        // Add the path to the frontier so it will be searched later
                        frontier.add(currentPathCopy);
                    }
                    // Go back to the last screen to continue iteration
                    device.pressBack();
                    // Check if this node was already visited
                    if (checkVisitedList(child)) {
                         //Remove this path from frontier since it would not be the shortest path
                        frontier.remove(currentPathCopy);
                        currentDepthIndex = previousDepthIndex;
                    }
                    // Check if this leads to the home screen
                    else if (checkBackPress()) {
                        // Remove this path from frontier since it will not help with the search
                        frontier.remove(currentPathCopy);
                        currentDepthIndex = previousDepthIndex;
                    }
                    else {
                        visitedNodes.add(child);
                    }
                    resetToStartScreen();
                    runInteractionPath(getInteractionPath(currentPath));
                    // Reset path and interaction variables for continued use
                    currentPathCopy = null;
                    currentInteraction = null;
                }
                // Press back as many times until we get to the home screen
                resetToStartScreen();
            }

        } while (frontier.size() != 0 && !finished && currentPath.size() < 9 && System.currentTimeMillis() <= endTime);
        if (System.currentTimeMillis() > endTime) {
            return "Package " + appPkg + ": Das Zeitlimit wurde überschritten.";
        }
        else {
            return "Package " + appPkg + ": Es wurden keine Datenschutzhinweise gefunden.";
        }
    }

    /**
     * Diese Methode überprüft, ob eine vorheriger BackPress auf den Home-Screen von Android geführt hat
     * und startet wenn nötig die Anwendung erneut.
     * @return true, wenn der BackPress auf den Home-Screen geführt hat
     */
    private boolean checkBackPress() {
        // Check if we are on the home screen
        if (device.getCurrentPackageName().equals(device.getLauncherPackageName())) {
            // Launch the app Folder
            UiObject appFolder = device.findObject(new UiSelector().description("Folder: Tested Apps"));
            try {
                appFolder.clickAndWaitForNewWindow();
                // Open the app again
                appIcon.clickAndWaitForNewWindow();
            } catch (UiObjectNotFoundException e) {
                Log.e(TAG, "Fehler in BFSSearch checkBackPress()", e);
            }
            return true;
        }
        else {
            return false;
        }
    }

    /**
     * Diese Methode navigiert zum Startbildschirm zurück und löst Probleme mit Toasts, sollten diese auftreten.
     */
    private void resetToStartScreen() {
        int i = 0;
        do {
            // Press back as long as the home screen is not reached
            device.pressBack();
            i++;
            // Deal with toasts by closing the app in the recent apps menu of android if pressing back 20 times did not lead to the home screen
            if (i >= 10) {
                device.pressHome();
                try {
                    device.pressRecentApps();
                    device.wait(Until.findObject(By.text("Clear all")), 2000);
                } catch (RemoteException e) {
                    Log.e(TAG, "Fehler in BFSSearch resetToStartScreen()", e);
                }
                UiObject clearButton = device.findObject(new UiSelector().text("Clear all").clickable(true));
                UiObject clearButtonSamsung = device.findObject(new UiSelector().text("CLOSE ALL").clickable(true));
                UiScrollable listView = new UiScrollable(new UiSelector().className("android.widget.ListView").scrollable(true));
                if (clearButtonSamsung != null && clearButtonSamsung.exists()) {
                    try {
                        clearButtonSamsung.clickAndWaitForNewWindow();
                    } catch (UiObjectNotFoundException e) {
                        e.printStackTrace();
                    }
                }
                else {
                    listView.setAsHorizontalList();
                    if (listView != null) {
                        try {
                            do {
                                listView.scrollToBeginning(4);
                            } while(clearButton != null && !clearButton.exists());
                            clearButton.clickAndWaitForNewWindow();
                        } catch (UiObjectNotFoundException e) {
                            Log.e(TAG, "Fehler in BFSSearch resetToStartScreen()", e);
                        }
                    }
                    else {
                        device.pressHome();
                    }
                }
            }
        } while (!checkBackPress());
    }

    /**
     * Diese Methode gibt den Interkationspfad zu einem zugehörigen Pfad von Knoten aus.
     * @param path der Pfad an Knoten
     * @return den zugehörigen Interaktionspfad
     */
    private ArrayList<AbstractEdgeInteraction> getInteractionPath(ArrayList<NodeScreen> path) {
        ArrayList<AbstractEdgeInteraction> interactionPath = new ArrayList<AbstractEdgeInteraction>();
        for (NodeScreen scr: path) {
            if (scr.getParentEdge() != null) {
                interactionPath.add(scr.getParentEdge());
            }
        }
        return interactionPath;
    }

    /**
     * Diese Methode führt einen Interaktionspfad aus.
     * @param path der auszuführende Pfad
     */
    private void runInteractionPath(ArrayList<AbstractEdgeInteraction> path) {
        if (path.size() == 0) {
            // do nothing
        }
        else {
            for (AbstractEdgeInteraction obj: path) {
                obj.interact();
            }
        }
    }

    /**
     *  Diese Methode prüft, ob ein Knoten einem der bereits besuchten Knoten gleicht.
     * @param screen der zu überprüfende Knoten
     * @return true, wenn der Knoten einem bereits besuchten Knoten gleicht, false wenn nicht
     */
    private boolean checkVisitedList(NodeScreen screen) {
        for (NodeScreen scr: visitedNodes) {
            if (screen.signatureEquals(scr)) {
                return true;
            }
        }
        return false;
    }

    /**
     *  Diese Methode baut den String, der den Pfad zu den gefundenen Datenschutzhinweisen präsentiert.
     * @return Den Ergebnispfad als String
     */
    private String finishSearch() {
        finished = true;
        String fin = appPkg + ":";
        ArrayList<NodeScreen> goalPath = new ArrayList<>(currentPath);
        AbstractEdgeInteraction edge;
        boolean scroll = false;

        for (NodeScreen s: goalPath) {
            edge = s.getParentEdge();
            if (edge == null) {
                fin = fin.concat("Start;");
            }
            else if (!edge.getEdgeText().equals("")) {
                if (edge.getEdgeText().equals("Scroll") && scroll == false) {
                    fin = fin.concat(edge.getEdgeText() + ";");
                    scroll = true;
                }
                else if (edge.getEdgeText().equals("Scroll") && scroll == true) {

                }
                else {
                    fin = fin.concat(edge.getEdgeText() + ";");
                    scroll = false;
                }
            }
            else if (!s.getNodeName().equals("")) {
                fin = fin.concat(s.getNodeName() + ";");
                scroll = false;
            }
            else {
                fin = fin.concat("Unclear;");
                scroll = false;
            }
            edge = null;
        }
        fin = fin.concat("DataPolicy;");
        return fin;
    }

    /**
     * Diese Methode baut den String, der den Pfad zu den gefundenen Datenschutzhinweisen präsentiert,
     * wenn dieser beim Durchsuchen eines anderen Knoten gefunden wurde.
     * @param screen der durchsuchte Knoten
     * @return den Ergebnispfad als String
     */
    private String finishSearchForLoop(NodeScreen screen) {
        finished = true;
        String fin = appPkg + ":";
        ArrayList<NodeScreen> goalPath = new ArrayList<>(currentPath);
        goalPath.add(screen);
        AbstractEdgeInteraction edge;
        boolean scroll = false;

        for (NodeScreen s: goalPath) {
            edge = s.getParentEdge();
            if (edge == null) {
                fin = fin.concat("Start;");
            }
            else if (!edge.getEdgeText().equals("")) {
                if (edge.getEdgeText().equals("Scroll") && scroll == false) {
                    fin = fin.concat(edge.getEdgeText() + ";");
                    scroll = true;
                }
                else if (edge.getEdgeText().equals("Scroll") && scroll == true) {

                }
                else {
                    fin = fin.concat(edge.getEdgeText() + ";");
                    scroll = false;
                }
            }
            else if (!s.getNodeName().equals("")) {
                fin = fin.concat(s.getNodeName() + ";");
                scroll = false;
            }
            else {
                fin = fin.concat("Unclear;");
                scroll = false;
            }
            edge = null;
        }
        fin = fin.concat("DataPolicy;");
        return fin;
    }

    /**
     * Diese Methode sortiert einen priorisierten Pfad anhand seiner Länge in die Frontier ein.
     * @param path der priorisierte Pfad
     */
    private void sortIntoFrontier(ArrayList<NodeScreen> path) {
        if (currentDepthIndex == frontier.size()) {
            frontier.add(path);
        }
        else {
            frontier.add(currentDepthIndex, path);
        }
    }


}
package com.example.bachelorthesisandroidproject;

import android.util.Log;

import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.uiautomator.By;
import androidx.test.uiautomator.UiDevice;
import androidx.test.uiautomator.UiObject;
import androidx.test.uiautomator.UiObject2;
import androidx.test.uiautomator.UiObjectNotFoundException;
import androidx.test.uiautomator.UiScrollable;
import androidx.test.uiautomator.UiSelector;

import java.util.ArrayList;
import java.util.List;

import static android.content.ContentValues.TAG;

/**
 * Diese Klasse implementiert die Repräsentation und Funktionalität eines Knotens in dem zu durchsuchenden Graphen.
 *
 * @version 1.1 20.08.2020
 * @author Jannis Dammann
 */
public class NodeScreen {

    /*
        These are the keywords used for the informed search. preferenceThreeStrings are the Strings that should have Data Policies behind them.
        preferenceTwoStrings are the Strings that could lead to the Data Policies.
     */
    private static final String[] preferenceThreeStrings = {"Data Policy", "Privacy Policy", "Policies", "Data policy", "Privacy policy", "Privacy Statement"};
    private static final String[] preferenceTwoStrings = {"Privacy", "Menu", "Profile", "Settings", "Account", "Privacy", "Help", "Options", "About", "Navigation", "Drawer", "Legal information", "Signed", "Legal", "Me"};

    private UiDevice device;
    private NodeScreen parent;                                  // The parent node
    private AbstractEdgeInteraction parentEdge;                 // The interaction that leads from the parent node to this node
    private ArrayList<AbstractEdgeInteraction> interactionList; // A list containing every interaction that is possible from this node
    private ArrayList<NodeScreen> childrenList;                 // A list containing a node for every interaction in the interactionList (all child nodes of this node)
    private String nodeSignature;                               // A String representing this node
    private String nodeName;                                    // The name of the node i.e. a heading text in the view

    /**
     * Konstruktor für die Klasse. Zuständig für die Instanziierung der Klassenvariablen.
     * @param screen der Elternknoten dieses Knotens
     * @param interaction die Interaktion, die zu diesem Knoten führt
     */
    public NodeScreen(NodeScreen screen, AbstractEdgeInteraction interaction) {
        device = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        parent = screen;
        parentEdge = interaction;
        interactionList = new ArrayList<AbstractEdgeInteraction>();
        childrenList = new ArrayList<NodeScreen>();
    }

    /**
     * Diese Methode ist dafür zuständig, im Falle einer uninformierten Suche den Knoten zu durchsuchen.
     * @return true, wenn ein Zielknoten von diesem Knoten aus erreichbar ist
     */
    public boolean setUp() {
        device = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        // check if there is a privacy policy button and if it is a solution
        if (checkForPolicyButton()) {
            return true;
        }
        // find all possible interactions/edges from this node
        try {
            findUiObjects();
            findUiScrollables();
        } catch (UiObjectNotFoundException e) {
            Log.e(TAG, "Fehler in NodeScreen setUp()", e);
        }
        // sort the interaction list based on the preference of the interactions
        sortInteractionList();
        // instantiate all child nodes in the children list
        for (AbstractEdgeInteraction e: interactionList) {
            childrenList.add(new NodeScreen(this, e));
        }
        // get String representation of node
        try {
            buildSignature();
        } catch (UiObjectNotFoundException e) {
            Log.e(TAG, "Fehler in NodeScreen setUp()", e);
        }
        return false;
    }

    /**
     * Diese Methode ist dafür zuständig, im Falle einer informierten Suche den Knoten zu durchsuchen.
     * @return true, wenn ein Zielknoten von diesem Knoten aus erreichbar ist
     */
    public boolean setUpInformedSearch() {
        device = UiDevice.getInstance(InstrumentationRegistry.getInstrumentation());
        // check if there is a privacy policy button and if it is a solution
        if (checkForPolicyButton()) {
            return true;
        }
        // find all possible interactions/edges from this node
        findUiObjectsInformed();
        findUiScrollables();
        // sort the interaction list based on the preference of the interactions
        sortInteractionList();
        // instantiate all child nodes in the children list
        for (AbstractEdgeInteraction e: interactionList) {
            childrenList.add(new NodeScreen(this, e));
        }
        // get String representation of node
        try {
            buildSignature();
        } catch (UiObjectNotFoundException e) {
            Log.e(TAG, "Fehler in NodeScreen setUpInformedSearch()", e);
        }
        return false;
    }

    /**
     * Diese Methode überprüft, ob ein Zielknoten von diesem Knoten aus erreichbar ist.
     * @return true, wenn ein Zielknoten erreichbar ist
     */
    private boolean checkForPolicyButton() {
        if (parent != null) {
            // look for objects with the text that would lead to privacy policies
            UiObject privacyPolicy = device.findObject(new UiSelector().text("Privacy Policy").clickable(true));
            UiObject dataPolicy = device.findObject(new UiSelector().text("Data Policy").clickable(true));

            if (privacyPolicy != null && privacyPolicy.exists()) {
                try {
                    privacyPolicy.clickAndWaitForNewWindow(5000);
                } catch (UiObjectNotFoundException e) {
                    Log.e(TAG, "Fehler in NodeScreen checkForPolicyButton()", e);
                }
                if (isGoal()) {
                    return true;
                }
                interactionList.add(new EdgeUiObject(privacyPolicy, 0));
            }
            if (dataPolicy != null && dataPolicy.exists()) {
                try {
                    dataPolicy.clickAndWaitForNewWindow(5000);
                } catch (UiObjectNotFoundException e) {
                    Log.e(TAG, "Fehler in NodeScreen checkForPolicyButton", e);
                }
                if (isGoal()) {
                    return true;
                }
                interactionList.add(new EdgeUiObject(dataPolicy, 0));
            }

            // look for texts for privacy policies that might have a clickable layout around them
            UiObject2 dataPolicyUnclickable = device.findObject(By.text("Data Policy").clickable(false));
            UiObject2 privacyPolicyUncklickable = device.findObject(By.text("Privacy Policy").clickable(false));

            if (dataPolicyUnclickable != null) {
                dataPolicyUnclickable.click(5000);
                if (isGoal()) {
                    return true;
                }
            }

            if (privacyPolicyUncklickable != null) {
                privacyPolicyUncklickable.click(5000);
                if (isGoal()) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Eine Methode, die im Falle eine uninformierten Suche alle UiObjects in der derzeitigen Ansicht findet
     * und diese der interactionList hinzufügt.
     * @throws UiObjectNotFoundException
     */
    private void findUiObjects() throws UiObjectNotFoundException {
        UiObject obj;
        int i;
        // Check for preferred objects
        findUiObjectsInformed();
        // Check for clickable objects that arent yet in the list
        i = 0;
        do {
            obj = null;
            obj = device.findObject(new UiSelector().clickable(true).instance(i));
            if (obj != null && obj.exists() && !edgeInList(obj)) {
                int pref;
                pref = getPreferenceLevel(obj);
                interactionList.add(new EdgeUiObject(obj, pref));
            }
            i++;
        } while (obj != null && obj.exists());
    }

    /**
     * Eine Methode, die alle UiObjects im Falle einer informierten Suche findet und der interactionList hinzufügt.
     */
    private void findUiObjectsInformed() {
        UiObject obj;
        int i;
        for (String s: preferenceThreeStrings) {
            i = 0;
            do {
                obj = null;
                obj = device.findObject(new UiSelector().textContains(s).instance(i));
                if (obj != null && obj.exists() && !edgeInList(obj)) {
                    interactionList.add(new EdgeUiObject(obj, 3));
                }
                obj = null;
                obj = device.findObject(new UiSelector().descriptionContains(s).instance(i));
                if (obj != null && obj.exists() && !edgeInList(obj)) {
                    interactionList.add(new EdgeUiObject(obj, 3));
                }
                obj = null;
                obj = device.findObject(new UiSelector().textContains(s.toLowerCase()).instance(i));
                if (obj != null && obj.exists() && !edgeInList(obj)) {
                    interactionList.add(new EdgeUiObject(obj, 3));
                }
                obj = null;
                obj = device.findObject(new UiSelector().descriptionContains(s.toLowerCase()).instance(i));
                if (obj != null && obj.exists() && !edgeInList(obj)) {
                    interactionList.add(new EdgeUiObject(obj, 3));
                }
                i++;
            } while (obj != null && obj.exists());
        }

        for (String s: preferenceTwoStrings) {
            i = 0;
            do {
                obj = null;
                obj = device.findObject(new UiSelector().textContains(s).instance(i));
                if (obj != null && obj.exists() && !edgeInList(obj)) {
                    interactionList.add(new EdgeUiObject(obj, 2));
                }
                obj = null;
                obj = device.findObject(new UiSelector().descriptionContains(s).instance(i));
                if (obj != null && obj.exists() && !edgeInList(obj)) {
                    interactionList.add(new EdgeUiObject(obj, 2));
                }
                obj = null;
                obj = device.findObject(new UiSelector().textContains(s.toLowerCase()).instance(i));
                if (obj != null && obj.exists() && !edgeInList(obj)) {
                    interactionList.add(new EdgeUiObject(obj, 2));
                }
                obj = null;
                obj = device.findObject(new UiSelector().descriptionContains(s.toLowerCase()).instance(i));
                if (obj != null && obj.exists() && !edgeInList(obj)) {
                    interactionList.add(new EdgeUiObject(obj, 2));
                }
                i++;
            } while (obj != null && obj.exists());
        }
    }

    /**
     * Eine Methode, die alle UiScrollables in einer Ansicht findet und der interactionList hinzufügt.
     */
    private void findUiScrollables() {
        int i = 0;
        UiScrollable scroll;
        do {
            scroll = null;
            scroll = new UiScrollable(new UiSelector().scrollable(true).instance(i++));
            if (scroll != null && scroll.exists()) {
                interactionList.add(new EdgeUiScrollable(scroll, 1));
            }
        } while (scroll != null && scroll.exists());
    }

    /**
     * Eine Methode, die überprüft, ob sich eine Interaktion bereits in der interactionList befindet.
     * @param obj das zu überprüfende UiObject
     * @return true, wenn sich obj in der Liste befindet
     */
    private boolean edgeInList(UiObject obj) {
        AbstractEdgeInteraction aei = new EdgeUiObject(obj, 0);
        for (AbstractEdgeInteraction edge: interactionList) {
            if (edge.getObject() != null && (obj.equals(edge.getObject()) || (aei.getClassname().equals(edge.getClassname()) && aei.getEdgeText().equals(edge.getEdgeText())))) {
                return true;
            }
        }
        return false;
    }

    /**
     * Eine Methode, die für ein UiObject dessen Präferenzlevel ermittelt.
     * @param obj das zu überprüfende UiObject
     * @return das Präferenzlevel des Objects
     * @throws UiObjectNotFoundException
     */
    private int getPreferenceLevel(UiObject obj) throws UiObjectNotFoundException {
        String contDesc = obj.getContentDescription();
        String text = obj.getText();

        if (stringPreference(contDesc) == 3 || stringPreference(text) == 3) {
            return 3;
        }
        if (stringPreference(contDesc) == 2 || stringPreference(text) == 2) {
            return 2;
        }
        return 0;
    }

    /**
     * Eine Methode, die die interactionList anhand der Präferenz der Interaktionen sortiert.
     */
    private void sortInteractionList() {
        ArrayList<AbstractEdgeInteraction> preferenceThree = new ArrayList<AbstractEdgeInteraction>();
        ArrayList<AbstractEdgeInteraction> preferenceTwo = new ArrayList<AbstractEdgeInteraction>();
        ArrayList<AbstractEdgeInteraction> preferenceOne = new ArrayList<AbstractEdgeInteraction>();
        ArrayList<AbstractEdgeInteraction> preferenceNull = new ArrayList<AbstractEdgeInteraction>();
        for (AbstractEdgeInteraction e: interactionList) {
            switch (e.getPreference()) {
                case 3:
                    preferenceThree.add(e);
                    break;
                case 2:
                    preferenceTwo.add(e);
                    break;
                case 1:
                    preferenceOne.add(e);
                    break;
                default:
                    preferenceNull.add(e);
            }
        }
        ArrayList<AbstractEdgeInteraction> sortedList = new ArrayList<AbstractEdgeInteraction>();
        sortedList.addAll(preferenceThree);
        sortedList.addAll(preferenceTwo);
        sortedList.addAll(preferenceOne);
        sortedList.addAll(preferenceNull);
        interactionList = null;
        interactionList = sortedList;
    }

    /**
     * Eine Methode, die überprüft, ob es sich bei diesem Knoten um einen Zielknoten handelt.
     * @return true, wenn dieser Knoten ein Zielknoten ist
     */
    public boolean isGoal() {
        UiObject2 dataPolicy = device.findObject(By.text("Data Policy").clickable(false));
        UiObject2 privacyPolicy = device.findObject(By.text("Privacy Policy").clickable(false));
        UiObject2 dataPolicyLowerCase = device.findObject(By.text("Data policy").clickable(false));
        UiObject2 privacyPolicyLowerCase = device.findObject(By.text("Privacy policy").clickable(false));
        UiObject2 datenschtzErklaerung = device.findObject(By.descContains("Web View"));
        if (dataPolicy != null || privacyPolicy != null || dataPolicyLowerCase != null || privacyPolicyLowerCase != null || datenschtzErklaerung != null) {
            return true;
        }
        else {
            return false;
        }
    }

    /**
     * Eine Methode, die überprüft, ob die Signatur eines Knotens mit der von diesem Knoten übereinstimmt.
     * @param screen der Knoten, der auf Gleichheit überprüft werden soll
     * @return true, wenn sich die Signaturen der beiden Knoten gleichen
     */
    public boolean signatureEquals(NodeScreen screen) {
        if (parentEdge != null && (parentEdge instanceof EdgeUiScrollable)) {
            return false;
        }
        else {
            return this.nodeSignature.equals(screen.getNodeSignature());
        }
    }

    /**
     * Eine Methode, die die String-Signatur dieses Knotens herstellt.
     * @throws UiObjectNotFoundException
     */
    private void buildSignature() throws UiObjectNotFoundException {
        nodeSignature = "";
        UiObject textViewName = device.findObject(new UiSelector().className("android.widget.TextView").clickable(false).instance(0));
        if (textViewName != null) {
            nodeName = textViewName.getText();
            nodeSignature = nodeSignature.concat(nodeName+";");
        }
        for (AbstractEdgeInteraction e: interactionList) {
            if (nodeSignature.length() <= 500) {
                nodeSignature = nodeSignature.concat(e.getClassname() + ";" + e.getEdgeText()+";");
            }
        }
    }

    /**
     * Eine Methode, die überprüft, ob es sich bei diesem Knoten um einen präferierten Knoten handelt.
     * @return true, wenn dieser Knoten bevorzugt ist
     */
    public boolean isPreferredNode() {
        if (interactionList.size() != 0) {
            int pref = interactionList.get(0).getPreference();
            if (pref == 3 || pref == 2) {
                return true;
            }
        }
        return false;
    }

    /**
     * Eine Methode, die das Präferenzlevel eines Strings ermittelt.
     * @param s der zu überprüfende String
     * @return das Präferenzlevel des Strings
     */
    private int stringPreference(String s) {
        for (int i = 0; i < preferenceThreeStrings.length; i++) {
            if(s.contains(preferenceThreeStrings[i])) {
                return 3;
            }
        }
        for (int i = 0; i < preferenceTwoStrings.length; i++) {
            if(s.contains(preferenceTwoStrings[i])) {
                return 2;
            }
        }
        return 0;
    }

    /**
     * Getter für die Elternkante
     * @return die Elternkante
     */
    public AbstractEdgeInteraction getParentEdge() {
        return parentEdge;
    }

    /**
     * Getter für die Interaktionsliste
     * @return die Interaktionsliste
     */
    public List<AbstractEdgeInteraction> getInteractionList() {
        return interactionList;
    }

    /**
     * Getter für die Kindesliste
     * @return die Kindesliste
     */
    public List<NodeScreen> getChildrenList() {
        return childrenList;
    }

    /**
     * Getter für die Signatur des Knotens
     * @return die Signatur des Knotens
     */
    public String getNodeSignature() {
        return nodeSignature;
    }

    /**
     * Getter für den Namen des Knotens
     * @return den Namen des Knotens
     */
    public String getNodeName() {
        return nodeName;
    }
}
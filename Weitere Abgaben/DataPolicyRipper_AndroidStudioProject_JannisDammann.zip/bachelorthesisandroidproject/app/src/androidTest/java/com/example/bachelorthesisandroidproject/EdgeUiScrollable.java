package com.example.bachelorthesisandroidproject;

import android.util.Log;

import androidx.test.uiautomator.UiObject;
import androidx.test.uiautomator.UiObjectNotFoundException;
import androidx.test.uiautomator.UiScrollable;

import static android.content.ContentValues.TAG;

/**
 * Diese Klasse erweitert die abstrakte Repräsentation einer Interaktion für ein UiScrollable.
 *
 * @version 1.0 11.08.2020
 * @author Jannis Dammann
 */
public class EdgeUiScrollable extends AbstractEdgeInteraction {

    private UiScrollable scrollable; // Das Scrollable/die Interaktion

    /**
     * Konstruktor der Klasse. Instanziiert alle Felder von der Super-Klasse sowie die von dieser Klasse.
     * @param scroll das UiScrollable
     * @param pref die Präferenz der Interaktion
     */
    public EdgeUiScrollable(UiScrollable scroll, int pref) {
        super(pref, "", "Scroll");
        scrollable = scroll;
        super.setClassname(buildClassname());
    }

    /**
     * Diese Methode führt eine Interaktion an dem UiScrollable durch.
     */
    public void interact() {
        try {
            scrollable.scrollForward();
        } catch (UiObjectNotFoundException e) {
            Log.e(TAG, "Fehler in EdgeUiScrollable interact()", e);
        }
    }

    /**
     * Diese Methode gibt Null aus, da es sich um ein Scrollable handelt.
     * @return null
     */
    public UiObject getObject() {
        return null;
    }

    /**
     * Diese Methode ermittelt den Typen der Interaktion als String.
     * @return den Typen der Interaktion als String
     */
    private String buildClassname() {
        String classname = "";
        try {
            for (String s: scrollable.getClassName().split("\\.")) {
                classname = s;
            }
        } catch (UiObjectNotFoundException e) {
            Log.e(TAG, "Fehler in EdgeUiScrollable buildClassname()", e);
        }
        return classname;
    }
}
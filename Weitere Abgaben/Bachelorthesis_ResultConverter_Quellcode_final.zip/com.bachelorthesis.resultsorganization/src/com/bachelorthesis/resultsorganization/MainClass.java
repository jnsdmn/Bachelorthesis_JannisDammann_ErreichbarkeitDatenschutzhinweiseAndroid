package com.bachelorthesis.resultsorganization;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
/**
 * Diese Klasse wirkt als die ausf�hrende Klasse f�r das Programm. Sie wird genutzt, um das Programm zu starten
 * und die Berechnung der Interaktionsh�ufigkeiten durchzuf�hren, sowie die GUI zu erstellen.
 * @author Jannis Dammann
 *
 */
public class MainClass {
	// Das Hauptframe
	private static JFrame frame;
	// Eine Liste an Knotenpaaren
	private static ArrayList<NodePair> nodesList;
	// Die String-Repr�sentation der Pfade aus der auszulesenden datei
	private static ArrayList<ArrayList<String>> stringList;
	// Array an bekannten Interaktionsnamen
	private static final String[] knownNodes = {"About", "Account", "Profile", "Settings", "Help", "Options", "Drawer", "Menu"};
	// Der k�rzeste Pfad
	private static ArrayList<String> shortestPath;
	// Der l�ngste Pfad
	private static ArrayList<String> longestPath;
	// Durchschnittliche Pfadl�nge
	private static double average;
	// Median der Pfadl�ngen
	private static double median;
	// Liste der L�nge der Pfade f�r die Berechnung des Durchschnitts
	private static ArrayList<Integer> lengthOfPaths;
	
	/**
	 * Ausf�hrende Methode
	 * @param args
	 */
	public static void main(String[] args) {
		// Creating GUI Frame
		frame = new JFrame("Bachelorthesis Jannis Dammann - Results to Graph Converter");
	    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    frame.setSize(600,600);
	    shortestPath = new ArrayList<>();
		longestPath = new ArrayList<>();
	    lengthOfPaths = new ArrayList<>();
		
	    String dir = System.getProperty("user.dir");
	    JFileChooser jfc = new JFileChooser(dir);
	    
	    // Creating JTextArea for showing the results and JButton for Saving
	    JTextArea ta = new JTextArea();
	    ta.setEditable(false);
	    
	    // Creating MenuBar with Components to Open File
	    JMenuBar mb = new JMenuBar();
	    JMenu menu = new JMenu("Convert File");
	    mb.add(menu);
	    JMenuItem item = new JMenuItem("Open File");
	    item.addActionListener(new ActionListener() {
	    	
	    	@Override
			public void actionPerformed(ActionEvent e) {
				
	    		if (jfc.showOpenDialog(frame) != JFileChooser.APPROVE_OPTION) {
					return;
				}
				File f = jfc.getSelectedFile();
	    		
				if(!f.toString().isEmpty()) {
					try {
						readFile(f.toString(), ta);
					} catch (IOException exception) {
						JOptionPane.showMessageDialog(frame, "Select a Txt Document in the right format", "Wrong format", JOptionPane.ERROR_MESSAGE);
					}
				}
			}
	    });
	    menu.add(item);
	    
	    JButton button = new JButton("Save to File");
	    button.addActionListener(new ActionListener() {
	    	
	    	@Override
	    	public void actionPerformed(ActionEvent e) {
	    		
	    		if (jfc.showSaveDialog(frame) != JFileChooser.APPROVE_OPTION) {
	    			return;
	    		}
	    		File f = jfc.getSelectedFile();
	    		
	    		if(!f.toString().isEmpty()) {
	    			saveFile(f.toString(), ta);
	    			frame.dispose();
	    		}
	    	}
	    });
	    
	    // Making the TextArea scrollable
	    JScrollPane scroll = new JScrollPane(ta);
	    scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	    scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
	    
	    // Adding Components to Frame
	    frame.getContentPane().add(BorderLayout.NORTH, mb);
	    frame.getContentPane().add(BorderLayout.CENTER, scroll);
	    frame.getContentPane().add(BorderLayout.SOUTH, button);
	    frame.setVisible(true);
	    

	}
	
	/**
	 * Diese Methode speichert die Analyseergebnisse in einer .txt Datei
	 * @param fn der Dateiname
	 * @param ta die JTextArea, die in die Datei gespeichert werden soll
	 */
	protected static void saveFile(String fn, JTextArea ta) {
		PrintWriter writer;
		try {
			writer = new PrintWriter(new FileWriter(fn , false));
			writer.println(ta.getText());
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Diese Methode liest eine Pfadliste aus einer .txt Datei aus und konvertiert diese in
	 * die Analyseergebnisse
	 * @param fn der Dateiname
	 * @param ta die JTextArea, in die die Ergebnisse geschrieben werden sollen
	 * @throws IOException
	 */
	protected static void readFile(String fn, JTextArea ta) throws IOException {
		stringList = new ArrayList<>();
		nodesList = new ArrayList<>();
		BufferedReader reader = new BufferedReader(new FileReader(fn));
		String line;
		String checkedString = "";
		ArrayList<String> lineList = new ArrayList<>();
		line = reader.readLine();
		while (line != null) {
			if (!line.contains("Es wurden keine Datenschutzhinweise gefunden.") && !line.contains("Das Zeitlimit wurde �berschritten.")) {
				String[] partsOfLine = line.split("\\;");
				lineList = new ArrayList<>();
				for (String s: partsOfLine) {
					if (s.contains("Results")) {
						lineList.add("Start");
					}
					else {
						checkedString = checkStringForKeyword(s);
						if (!checkedString.equals("")) {
							lineList.add(checkedString);
						}
						else {
							lineList.add(s);
						}
					}
				}
			}
			if (lineList.size() != 1) {
				dealWithNumbers(lineList);
			}
			stringList.add(lineList);
			line = reader.readLine();
		}
		reader.close();
		calculateMetrics();
		createAndCountNodes();
		printNodes(ta);
	}
	
	/**
	 * Diese Methode ist f�r die Speicherung der Pfadl�ngen und der Haltung des
	 * derzeizig k�rzesten und des derzeitig l�ngsten Pfades zust�ndig.
	 * @param lineList String-Liste, die einen Ergebnispfad repr�sentiert
	 */
	private static void dealWithNumbers(ArrayList<String> lineList) {
		int pathLength = lineList.size() - 1;
		lengthOfPaths.add(pathLength);
		
		if (shortestPath.size() > lineList.size() || shortestPath.size() == 0) {
			shortestPath = new ArrayList<String>(lineList);
		}
		if (longestPath.size() < lineList.size()) {
			longestPath = new ArrayList<String>(lineList);
		}
	}

	/**
	 * Diese Methode schreibt die Knotenpaare mit ihren H�ufigkeiten in die TextArea
	 * @param ta die JTextArea, in die die Ergebnisse geschrieben werden sollen
	 */
	private static void printNodes(JTextArea ta) {
		ArrayList<String> toBePrintedList = new ArrayList<>();
		ArrayList<String> alreadyPrintedList = new ArrayList<>();
		ta.setText("");
		toBePrintedList.add("Start");
		do {
			for (NodePair np: nodesList) {
				if (np.getNodeOne().equals(toBePrintedList.get(0))) {
					ta.append(np.getStringRepresentation() + "\n");
					if (!stringInList(alreadyPrintedList, np.getNodeTwo()) && !stringInList(toBePrintedList, np.getNodeTwo())) {
						toBePrintedList.add(np.getNodeTwo());
					}
				}
			}
			alreadyPrintedList.add(toBePrintedList.get(0));
			toBePrintedList.remove(0);
		} while(toBePrintedList.size() != 0);
		
		StringBuilder sP = new StringBuilder();
		for (String s: shortestPath) {
			sP.append(s + ";");
		}
		ta.append("Shortest Path: " + sP.toString() + "\n");
		StringBuilder lP = new StringBuilder();
		for (String s: longestPath) {
			lP.append(s + ";");
		}
		ta.append("Longest Path: " + lP.toString() + "\n");
		ta.append("Average path length: " + Double.toString(average) + "\n");
		ta.append("Median path length: " + Double.toString(median));
	}

	/**
	 * Diese Methode �berpr�ft, ob ein Knoten bereits in einer String-Liste enthalten ist
	 * @param alreadyPrintedList die zu �berpr�fende Liste an Strings
	 * @param nodeTwo der zu �berpr�fende Knoten
	 * @return true, wenn der Knoten bereits in der Liste enthalten ist
	 */
	private static boolean stringInList(ArrayList<String> alreadyPrintedList, String nodeTwo) {
		for (String s: alreadyPrintedList) {
			if (s.equals(nodeTwo)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Diese Methode erstellt die Knotenpaare und z�hlt ihre H�ufigkeit
	 */
	private static void createAndCountNodes() {
		for (ArrayList<String> currentPath: stringList) {
			for (int i = 0; i < currentPath.size()-1; i++) {
				int j = i + 1;
				String str = isInNodeList(currentPath.get(i) + ";" + currentPath.get(j) + ";");
				if (!str.equals("Not in List")) {
					int index = Integer.parseInt(str);
					nodesList.get(index).incrementCount();
				}
				else {
					nodesList.add(new NodePair(currentPath.get(i), currentPath.get(j)));
				}
			}
		}
	}
	
	/**
	 * Diese Methode �berpr�ft, ob ein String einen der bereits bekannten Interaktionen
	 * beinhaltet.
	 * @param s der zu �berpr�fende String
	 * @return die Position des Knotens in der nodesList, bzw. "Not in List", wenn der String keinen bekannten Knoten enth�lt.
	 */
	private static String isInNodeList (String s) {
		if (nodesList.size() == 0) {
			return "Not in List";
		}
		for (int i = 0; i < nodesList.size(); i++) {
			NodePair np = nodesList.get(i);
			String pair = np.getNodeStrings();
			if (pair.toLowerCase().equals(s.toLowerCase())) {
				return Integer.toString(i);
			}
		}
		return "Not in List";
	}
	
	/**
	 * �berpr�ft, ob ein String einen der bekannten Interaktionsnamen beinhaltet.
	 * @param str der zu �berpr�fende String
	 * @return den Interaktionsnamen
	 */
	private static String checkStringForKeyword(String str) {
		for (String s: knownNodes) {
			if (str.toLowerCase().contains(s.toLowerCase())) {
				return s;
			}
		}
		return "";
	}
	
	/**
	 * Diese Methode berechnet den Durchschnitt sowie den Median
	 */
	private static void calculateMetrics() {
		Collections.sort(lengthOfPaths);
		double numberOfNodes = 0.0d;
		for (int i : lengthOfPaths) {
			numberOfNodes = numberOfNodes + (double) i;
		}
		average = numberOfNodes / lengthOfPaths.size();
		int middle = lengthOfPaths.size() / 2;
		if (stringList.size() % 2 == 0) {
			median = ((double) (lengthOfPaths.get(middle - 1) + lengthOfPaths.get(middle)))/2;
		} else {
			median = ((double) lengthOfPaths.get(middle));
		}
		
	}

}
